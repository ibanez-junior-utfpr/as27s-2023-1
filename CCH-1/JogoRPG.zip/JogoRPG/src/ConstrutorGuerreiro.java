// Concrete Builder: Construtor de Guerreiro
public class ConstrutorGuerreiro extends ConstrutorDePersonagem {
    @Override
    public void construirHabilidades() {
        personagem.setHabilidades("Ataque Físico, Defesa");
    }

    @Override
    public void construirEquipamentos() {
        personagem.setEquipamentos("Espada, Armadura Pesada");
    }
}
