// Diretor: Criador de Personagens
public class CriadorDePersonagens {
	private ConstrutorDePersonagem construtor;

    public void setConstrutor(ConstrutorDePersonagem construtor) {
        this.construtor = construtor;
    }

    public Personagem getPersonagem() {
        return construtor.getPersonagem();
    }

    public void criarPersonagem(String nome, String classe, String raca) {
        construtor.criarNovoPersonagem(nome, classe, raca);
        construtor.construirHabilidades();
        construtor.construirEquipamentos();
    }
}
