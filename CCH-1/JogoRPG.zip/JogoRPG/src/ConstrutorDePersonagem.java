// Builder: Construtor de Personagens
public abstract class ConstrutorDePersonagem {
	protected Personagem personagem;

    public Personagem getPersonagem() {
        return personagem;
    }

    public void criarNovoPersonagem(String nome, String classe, String raca) {
        personagem = new Personagem(nome, classe, raca);
    }

    public abstract void construirHabilidades();
    public abstract void construirEquipamentos();
}
