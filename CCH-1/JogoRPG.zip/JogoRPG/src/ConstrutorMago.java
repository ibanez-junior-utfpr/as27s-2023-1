// Concrete Builder: Construtor de Mago
public class ConstrutorMago extends ConstrutorDePersonagem {
    @Override
    public void construirHabilidades() {
        personagem.setHabilidades("Magia de Fogo, Magia de Gelo");
    }

    @Override
    public void construirEquipamentos() {
        personagem.setEquipamentos("Varinha, Manto Mágico");
    }
}
