// Exemplo de uso
public class ExemploBuilder {

	public static void main(String[] args) {
		CriadorDePersonagens criador = new CriadorDePersonagens();

        ConstrutorDePersonagem construtorGuerreiro = new ConstrutorGuerreiro();
        criador.setConstrutor(construtorGuerreiro);
        criador.criarPersonagem("Guerreiro1", "Guerreiro", "Humano");
        Personagem guerreiro = criador.getPersonagem();
        System.out.println(guerreiro);

        ConstrutorDePersonagem construtorMago = new ConstrutorMago();
        criador.setConstrutor(construtorMago);
        criador.criarPersonagem("Mago1", "Mago", "Elfo");
        Personagem mago = criador.getPersonagem();
        System.out.println(mago);
	}
}
