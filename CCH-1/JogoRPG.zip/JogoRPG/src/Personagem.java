// Produto: Personagem
public class Personagem {
	private String nome;
    private String classe;
    private String raca;
    private String habilidades;
    private String equipamentos;

    public Personagem(String nome, String classe, String raca) {
        this.nome = nome;
        this.classe = classe;
        this.raca = raca;
    }

    public void setHabilidades(String habilidades) {
        this.habilidades = habilidades;
    }

    public void setEquipamentos(String equipamentos) {
        this.equipamentos = equipamentos;
    }

    @Override
    public String toString() {
    	return "Personagem: " + nome + ", Classe: " + classe + ", Raça: " + raca
    			+ "\nHabilidades: " + habilidades
    			+ "\nEquipamentos: " + equipamentos;
    }
}
