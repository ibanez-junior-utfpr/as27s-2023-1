// Classe abstrata Entrega
public abstract class Entrega {
	 protected Transportadora transportadora;

	 public Entrega(Transportadora transportadora) {
	        this.transportadora = transportadora;
	 }

	 public abstract void processarEntrega();
}
