// Subclasses de Entrega: EmSeparacao
public class EmSeparacao extends Entrega {
    public EmSeparacao(Transportadora transportadora) {
        super(transportadora);
    }

    @Override
    public void processarEntrega() {
        System.out.println("Entrega em separação");
        transportadora.enviar();
    }
}
