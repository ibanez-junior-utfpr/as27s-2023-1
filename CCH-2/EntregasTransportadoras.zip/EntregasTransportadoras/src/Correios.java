// Implementação de Transportadora: Correios
public class Correios implements Transportadora {
    @Override
    public void enviar() {
        System.out.println("Enviando via Correios");
    }
}
