// Exemplo: Bridge
public class ExemploBridge {
	public static void main(String[] args) {
        // Criando instâncias das transportadoras
        Transportadora correios = new Correios();
        Transportadora transportadoraSuperSul = new TransportadoraSuperSul();
        Transportadora transportadoraSuperNorte = new TransportadoraSuperNorte();

        // Realizando algumas entregas
        Entrega entrega1 = new Pendente(correios);
        entrega1.processarEntrega();

        Entrega entrega2 = new EmSeparacao(transportadoraSuperSul);
        entrega2.processarEntrega();

        Entrega entrega3 = new Enviada(transportadoraSuperNorte);
        entrega3.processarEntrega();

        Entrega entrega4 = new Finalizada(correios);
        entrega4.processarEntrega();
	}
}
