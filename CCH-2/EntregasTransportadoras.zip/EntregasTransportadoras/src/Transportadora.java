// Interface Transportadora
public interface Transportadora {
	public abstract void enviar();
}
