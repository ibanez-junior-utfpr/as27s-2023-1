// Subclasses de Entrega: Pendente
public class Pendente extends Entrega {
    public Pendente(Transportadora transportadora) {
        super(transportadora);
    }

    @Override
    public void processarEntrega() {
        System.out.println("Entrega pendente");
        transportadora.enviar();
    }
}
