// Implementação de Transportadora: TransportadoraSuperNorte
public class TransportadoraSuperNorte implements Transportadora {
    @Override
    public void enviar() {
        System.out.println("Enviando via Transportadora SuperNorte");
    }
}
