// Subclasses de Entrega: Enviada
public class Enviada extends Entrega {
    public Enviada(Transportadora transportadora) {
        super(transportadora);
    }

    @Override
    public void processarEntrega() {
        System.out.println("Entrega enviada");
        transportadora.enviar();
    }
}
