// Implementação de Transportadora: TransportadoraSuperSul
public class TransportadoraSuperSul implements Transportadora {
    @Override
    public void enviar() {
        System.out.println("Enviando via Transportadora SuperSul");
    }
}
