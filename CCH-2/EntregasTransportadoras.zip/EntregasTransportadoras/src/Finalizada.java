// Subclasses de Entrega: Finalizada
public class Finalizada extends Entrega {
    public Finalizada(Transportadora transportadora) {
        super(transportadora);
    }

    @Override
    public void processarEntrega() {
        System.out.println("Entrega concluída");
        transportadora.enviar();
    }
}
