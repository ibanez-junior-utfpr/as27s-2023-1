
public class Cesta {

	public static void main(String[] args) {
		Venda cesta = new Venda();
		cesta.setFormaPagto(new Cartao());
		cesta.pagar(100.00);
		cesta.setFormaPagto(new Pix());
		cesta.pagar(50.00);
		cesta.setFormaPagto(new Dinheiro());
		cesta.pagar(30.00);
	}

}
