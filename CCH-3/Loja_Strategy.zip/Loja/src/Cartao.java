
public class Cartao implements FormaPagto {
	public void pagamento(double valor) {
		System.out.println("Pagou: " + valor + " com Cartão");
	}
}
