
public class Venda {
	private FormaPagto tipo;
	
	public void setFormaPagto(FormaPagto tipo) {
		this.tipo = tipo;
	}
	
	public void pagar(double valor) {
		this.tipo.pagamento(valor);
	}
}
