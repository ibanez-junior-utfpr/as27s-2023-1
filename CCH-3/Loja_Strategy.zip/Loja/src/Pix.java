
public class Pix implements FormaPagto {
	public void pagamento(double valor) {
		System.out.println("Pagou: " + valor + " com PIX");
	}
}
