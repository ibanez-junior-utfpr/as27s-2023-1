
public interface FormaPagto {
	public void pagamento(double valor);
}
