
public class Dinheiro implements FormaPagto {
	public void pagamento(double valor) {
		System.out.println("Pagou: " + valor + " com Dinheiro");
	}
}
